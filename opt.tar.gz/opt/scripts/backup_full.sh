usage () {
  cat << EOF
Usage: $0 -s <origen> -d <destino>
       $0 -h | --help 
EOF
  exit 1
}

while getopts "hs:d:-:" opt; do
 case $opt in
  h) usage ;;
  s) SRC="$OPTARG" ;;
  d) DST="$OPTARG" ;;
  -)
    case "${OPTARG}" in
     help) usage ;;
     *) echo "Opcion desconocida -- ${OPTARG}"; usage ;;
    esac
    ;;
    *) usage ;;
 esac
done

[[ -z "%SRC" || -z "$DST" ]] && usage

mountpoint -q "$SRC" || { echo "Error: $SRC no montado"; exit 2; }
mountpoint -q "$DST" || { echo "Error: $DST no montado"; exit 2; }

DATE=$(date +%Y%m%d)
BASE=$(basename "$SRC")
FILENAME="${BASE}_bkp_${DATE}.tar.gz"

tar -czpf "$DST/$FILENAME" -C "$(dirname "$SRC")" "$BASE"
